// ============================================================
// server.js — Node.js Backend (WebSocket + REST + MongoDB)
// ============================================================
const express = require("express");
const http    = require("http");
const { WebSocketServer } = require("ws");
const mongoose = require("mongoose");
const cors     = require("cors");

const app = express();
app.use(cors({ origin: "*" }));
app.use(express.json());

// ── 1. MONGODB ───────────────────────────────────────────────
mongoose.connect("mongodb://127.0.0.1:27017/collabdocs")
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.log("⚠️  MongoDB not connected:", err.message, "\n   (App still works — edits just won't persist)"));

const documentSchema = new mongoose.Schema({
  _id:      { type: String },
  title:    { type: String, default: "Untitled Document" },
  content:  { type: String, default: "" },
  version:  { type: Number, default: 0 },
  updatedAt:{ type: Date, default: Date.now },
});
const Document = mongoose.model("Document", documentSchema);

// In-memory fallback when MongoDB is unavailable
const memStore = {};

async function getDoc(docId) {
  try {
    let doc = await Document.findById(docId);
    if (!doc) {
      doc = new Document({ _id: docId });
      await doc.save();
    }
    return { content: doc.content, title: doc.title, version: doc.version };
  } catch {
    if (!memStore[docId]) memStore[docId] = { content: "", title: "Untitled Document", version: 0 };
    return memStore[docId];
  }
}

async function saveDoc(docId, data) {
  try {
    await Document.findByIdAndUpdate(docId, { ...data, updatedAt: new Date() }, { upsert: true });
  } catch {
    memStore[docId] = { ...(memStore[docId] || {}), ...data };
  }
}

// ── 2. REST ROUTES ───────────────────────────────────────────
app.get("/", (req, res) => res.json({ status: "CollabDocs server running ✅" }));
app.get("/api/documents/:id", async (req, res) => res.json(await getDoc(req.params.id)));

// ── 3. HTTP + WEBSOCKET SERVER ───────────────────────────────
const server = http.createServer(app);
const wss    = new WebSocketServer({ server, verifyClient: () => true });

const rooms  = new Map(); // Map<docId, Set<{ws, userId, userName, color}>>
const COLORS = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#A78BFA"];

function broadcast(docId, message, excludeWs = null) {
  const room = rooms.get(docId);
  if (!room) return;
  const data = JSON.stringify(message);
  let sent = 0;
  room.forEach(c => {
    if (c.ws !== excludeWs && c.ws.readyState === 1) { c.ws.send(data); sent++; }
  });
  console.log(`📡 [${message.type}] → ${sent} client(s) in room "${docId}"`);
}

wss.on("connection", (ws, req) => {
  console.log(`🟢 New connection from ${req.socket.remoteAddress}`);

  let docId = null;
  let user  = { userId: "anon", userName: "Anonymous", color: "#888" };

  const ping = setInterval(() => { if (ws.readyState === 1) ws.ping(); }, 25000);

  ws.on("message", async (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); }
    catch { console.error("Bad JSON:", raw.toString()); return; }

    console.log(`📨 [${msg.type}] from "${msg.userName || user.userName}"`);

    if (msg.type === "join") {
      docId = msg.docId;
      user  = { userId: msg.userId, userName: msg.userName, color: msg.color || COLORS[Math.floor(Math.random()*COLORS.length)] };

      if (!rooms.has(docId)) rooms.set(docId, new Set());
      rooms.get(docId).add({ ws, ...user });
      console.log(`📥 "${user.userName}" joined doc "${docId}" — ${rooms.get(docId).size} user(s)`);

      // Send current doc state to new joiner
      const doc = await getDoc(docId);
      ws.send(JSON.stringify({ type: "init", ...doc }));

      // Tell others someone new joined
      broadcast(docId, { type: "user_joined", ...user }, ws);

      // Send full user list to new joiner
      const list = [...rooms.get(docId)].map(c => ({ userId: c.userId, userName: c.userName, color: c.color }));
      ws.send(JSON.stringify({ type: "users", users: list }));
    }

    else if (msg.type === "edit") {
      const newVersion = (msg.version || 0) + 1;
      await saveDoc(msg.docId, { content: msg.content, version: newVersion });
      broadcast(msg.docId, { type: "edit", content: msg.content, userId: msg.userId, userName: msg.userName, version: newVersion }, ws);
    }

    else if (msg.type === "title") {
      await saveDoc(msg.docId, { title: msg.title });
      broadcast(msg.docId, { type: "title", title: msg.title, userId: user.userId }, ws);
    }

    else if (msg.type === "cursor") {
      broadcast(msg.docId, { type: "cursor", userId: user.userId, position: msg.position, color: user.color }, ws);
    }
  });

  ws.on("close", (code) => {
    clearInterval(ping);
    console.log(`🔴 "${user.userName}" disconnected (code ${code})`);
    if (docId && rooms.has(docId)) {
      const room = rooms.get(docId);
      room.forEach(c => { if (c.ws === ws) room.delete(c); });
      if (room.size === 0) rooms.delete(docId);
      else broadcast(docId, { type: "user_left", userId: user.userId, userName: user.userName });
    }
  });

  ws.on("error", err => console.error(`❌ WS error:`, err.message));
});

// ── 4. START ─────────────────────────────────────────────────
const PORT = 4000;
server.listen(PORT, "0.0.0.0", () => {
  console.log("\n========================================");
  console.log(`🚀 HTTP  →  http://localhost:${PORT}`);
  console.log(`🔌 WS    →  ws://localhost:${PORT}`);
  console.log("========================================\n");
});