import { useState, useEffect, useRef, useCallback } from "react";

// ─── Real WebSocket connection to backend ───────────────────
const WS_URL = "ws://localhost:4000";
const DOC_ID = "shared-doc-001"; // All tabs share this document

const COLORS = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD"];
const CURRENT_USER = {
  id: "user-" + Math.random().toString(36).substr(2, 6),
  name: "User-" + Math.random().toString(36).substr(2, 3).toUpperCase(),
  color: COLORS[Math.floor(Math.random() * COLORS.length)],
};

const INITIAL_CONTENT = `Welcome to CollabDocs ✦

This is a real-time collaborative document editor. Multiple users can edit this document simultaneously.

Start typing to see changes reflected in real-time across all connected clients.

Features:
→ Real-time synchronization via WebSocket
→ Presence awareness (see who's online)
→ Conflict-free collaborative editing (OT/CRDT)
→ Persistent storage with MongoDB/PostgreSQL
→ Version history and change tracking`;

export default function App() {
  const [content, setContent] = useState(INITIAL_CONTENT);
  const [users, setUsers] = useState([{ ...CURRENT_USER, name: "You (" + CURRENT_USER.name + ")" }]);
  const [connected, setConnected] = useState(false);
  const [docTitle, setDocTitle] = useState("Untitled Document");
  const [editingTitle, setEditingTitle] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [wordCount, setWordCount] = useState(0);
  const [showSidebar, setShowSidebar] = useState(true);
  const [activeTab, setActiveTab] = useState("users");
  const [history, setHistory] = useState([]);
  const wsRef = useRef(null);
  const editorRef = useRef(null);
  const saveTimeoutRef = useRef(null);
  const notifIdRef = useRef(0);
  const isRemoteUpdate = useRef(false);
  const versionRef = useRef(0);

  const addNotification = useCallback((msg, type = "info") => {
    const id = ++notifIdRef.current;
    setNotifications(prev => [...prev, { id, msg, type }]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 3000);
  }, []);

  // ── Connect to real WebSocket backend ──
  useEffect(() => {
    let reconnectTimer = null;

    function connect() {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        addNotification("Connected to document server", "success");
        // Join the shared document room
        ws.send(JSON.stringify({
          type: "join",
          docId: DOC_ID,
          userId: CURRENT_USER.id,
          userName: CURRENT_USER.name,
          color: CURRENT_USER.color,
        }));
      };

      ws.onmessage = (e) => {
        const data = JSON.parse(e.data);

        // Server sends current doc state when you first join
        if (data.type === "init") {
          if (data.content) {
            isRemoteUpdate.current = true;
            setContent(data.content);
          }
          if (data.title) setDocTitle(data.title);
          if (data.version) versionRef.current = data.version;
        }

        // Another user edited the document
        if (data.type === "edit") {
          isRemoteUpdate.current = true;
          setContent(data.content);
          versionRef.current = data.version || versionRef.current + 1;
          setHistory(h => [...h.slice(-19), {
            time: new Date(),
            user: data.userName || "Someone",
            action: "edited"
          }]);
        }

        // Another user joined
        if (data.type === "user_joined") {
          setUsers(prev => {
            if (prev.find(u => u.id === data.userId)) return prev;
            addNotification(`${data.userName} joined`, "info");
            return [...prev, { id: data.userId, name: data.userName, color: data.color }];
          });
        }

        // Server sends full user list on join
        if (data.type === "users") {
          const others = data.users.filter(u => u.userId !== CURRENT_USER.id);
          const me = { ...CURRENT_USER, name: "You (" + CURRENT_USER.name + ")" };
          setUsers([me, ...others.map(u => ({ id: u.userId, name: u.userName, color: u.color }))]);
        }

        // A user left
        if (data.type === "user_left") {
          setUsers(prev => prev.filter(u => u.id !== data.userId));
          addNotification(`${data.userName} left`, "info");
        }

        // Title updated by another user
        if (data.type === "title") {
          setDocTitle(data.title);
        }
      };

      ws.onclose = () => {
        setConnected(false);
        addNotification("Disconnected — reconnecting...", "info");
        // Auto-reconnect after 3 seconds
        reconnectTimer = setTimeout(connect, 3000);
      };

      ws.onerror = () => {
        ws.close();
      };
    }

    connect();

    return () => {
      clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, []);

  useEffect(() => {
    const words = content.trim().split(/\s+/).filter(Boolean).length;
    setWordCount(words);
  }, [content]);

  const handleChange = (e) => {
    // Ignore if this was a remote update setting the content
    if (isRemoteUpdate.current) {
      isRemoteUpdate.current = false;
      return;
    }
    const newContent = e.target.value;
    setContent(newContent);
    // Send real edit to backend WebSocket
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: "edit",
        docId: DOC_ID,
        content: newContent,
        userId: CURRENT_USER.id,
        userName: CURRENT_USER.name,
        version: versionRef.current,
      }));
    }
    // Auto-save indicator
    clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      setLastSaved(new Date());
      setHistory(h => [...h.slice(-19), { time: new Date(), user: "You", action: "saved" }]);
    }, 1500);
  };

  const handleTitleSave = () => {
    setEditingTitle(false);
    // Broadcast title change to all users
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: "title",
        docId: DOC_ID,
        title: docTitle,
        userId: CURRENT_USER.id,
      }));
    }
    addNotification("Title updated", "success");
  };

  const formatTime = (date) => {
    if (!date) return "Never";
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div style={styles.root}>
      {/* Animated background */}
      <div style={styles.bgLayer} />

      {/* Notifications */}
      <div style={styles.notifContainer}>
        {notifications.map(n => (
          <div key={n.id} style={{ ...styles.notif, ...(n.type === "success" ? styles.notifSuccess : styles.notifInfo) }}>
            <span style={styles.notifDot} />
            {n.msg}
          </div>
        ))}
      </div>

      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logo}>
            <span style={styles.logoIcon}>✦</span>
            <span style={styles.logoText}>CollabDocs</span>
          </div>
          <div style={styles.divider} />
          {editingTitle ? (
            <input
              autoFocus
              value={docTitle}
              onChange={e => setDocTitle(e.target.value)}
              onBlur={handleTitleSave}
              onKeyDown={e => e.key === "Enter" && handleTitleSave()}
              style={styles.titleInput}
            />
          ) : (
            <button style={styles.titleBtn} onClick={() => setEditingTitle(true)}>
              {docTitle}
              <span style={styles.editIcon}>✎</span>
            </button>
          )}
        </div>
        <div style={styles.headerCenter}>
          <div style={{ ...styles.statusBadge, ...(connected ? styles.statusOnline : styles.statusOffline) }}>
            <span style={styles.statusDot} />
            {connected ? "Live" : "Offline"}
          </div>
        </div>
        <div style={styles.headerRight}>
          <div style={styles.avatarStack}>
            {users.slice(0, 5).map((u, i) => (
              <div key={u.id} title={u.name} style={{ ...styles.avatar, background: u.color, marginLeft: i > 0 ? -10 : 0, zIndex: 10 - i }}>
                {u.name[0]}
              </div>
            ))}
            {users.length > 5 && <div style={{ ...styles.avatar, background: "#555", marginLeft: -10 }}>+{users.length - 5}</div>}
          </div>
          <button style={styles.shareBtn} onClick={() => addNotification("Link copied!", "success")}>
            Share ↗
          </button>
          <button style={{ ...styles.sidebarToggle, ...(showSidebar ? styles.sidebarToggleActive : {}) }} onClick={() => setShowSidebar(s => !s)}>
            ⊞
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div style={styles.toolbar}>
        {["B", "I", "U", "S"].map(t => (
          <button key={t} style={styles.toolBtn} title={t}>
            <span style={{ fontWeight: t === "B" ? 900 : 400, fontStyle: t === "I" ? "italic" : "normal", textDecoration: t === "U" ? "underline" : t === "S" ? "line-through" : "none" }}>
              {t}
            </span>
          </button>
        ))}
        <div style={styles.toolSep} />
        {["H1", "H2", "¶"].map(t => (
          <button key={t} style={styles.toolBtn}>{t}</button>
        ))}
        <div style={styles.toolSep} />
        {["≡", "•≡", "1≡"].map(t => (
          <button key={t} style={styles.toolBtn}>{t}</button>
        ))}
        <div style={styles.toolSep} />
        <button style={styles.toolBtn} title="Insert Link">⊕ Link</button>
        <button style={styles.toolBtn} title="Insert Image">⊕ Image</button>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 12 }}>
          <span style={styles.meta}>{wordCount} words · {content.length} chars</span>
          <span style={styles.meta}>Saved {formatTime(lastSaved)}</span>
        </div>
      </div>

      {/* Main area */}
      <div style={styles.main}>
        {/* Editor */}
        <div style={styles.editorWrap}>
          <div style={styles.page}>
            <textarea
              ref={editorRef}
              value={content}
              onChange={handleChange}
              style={styles.editor}
              placeholder="Start writing..."
              spellCheck
            />
          </div>
        </div>

        {/* Sidebar */}
        {showSidebar && (
          <aside style={styles.sidebar}>
            <div style={styles.sidebarTabs}>
              {["users", "history"].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  style={{ ...styles.tabBtn, ...(activeTab === tab ? styles.tabBtnActive : {}) }}
                >
                  {tab === "users" ? "👥 People" : "📋 History"}
                </button>
              ))}
            </div>

            {activeTab === "users" && (
              <div style={styles.sidebarContent}>
                <p style={styles.sidebarLabel}>ACTIVE NOW — {users.length}</p>
                {users.map(u => (
                  <div key={u.id} style={styles.userRow}>
                    <div style={{ ...styles.userDot, background: u.color }} />
                    <div>
                      <div style={styles.userName}>{u.name} {u.id === CURRENT_USER.id && "(you)"}</div>
                      <div style={styles.userStatus}>Editing · Just now</div>
                    </div>
                  </div>
                ))}
                <div style={styles.sectionDivider} />
                <p style={styles.sidebarLabel}>SHARE ACCESS</p>
                <div style={styles.shareBox}>
                  <input readOnly value="https://collabdocs.io/doc/xK9a..." style={styles.shareInput} />
                  <button style={styles.copyBtn} onClick={() => addNotification("Copied!", "success")}>Copy</button>
                </div>
                <div style={styles.permRow}>
                  <span style={styles.permLabel}>Anyone with link</span>
                  <select style={styles.permSelect}>
                    <option>Can Edit</option>
                    <option>Can View</option>
                    <option>No Access</option>
                  </select>
                </div>
              </div>
            )}

            {activeTab === "history" && (
              <div style={styles.sidebarContent}>
                <p style={styles.sidebarLabel}>RECENT CHANGES</p>
                {history.length === 0 && <p style={styles.emptyState}>No changes yet</p>}
                {[...history].reverse().map((h, i) => (
                  <div key={i} style={styles.historyRow}>
                    <div style={styles.historyDot} />
                    <div>
                      <div style={styles.historyText}><strong>{h.user}</strong> {h.action}</div>
                      <div style={styles.historyTime}>{formatTime(h.time)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </aside>
        )}
      </div>

      {/* Status bar */}
      <footer style={styles.footer}>
        <span style={styles.footerItem}>
          <span style={{ ...styles.dot, background: connected ? "#4ECDC4" : "#FF6B6B" }} />
          {connected ? `Connected · ${users.length} user${users.length > 1 ? "s" : ""} online` : "Reconnecting..."}
        </span>
        <span style={styles.footerItem}>MongoDB · WebSocket · React</span>
        <span style={styles.footerItem}>CollabDocs v1.0</span>
      </footer>
    </div>
  );
}

const styles = {
  root: {
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    background: "#0D0D14",
    color: "#E8E8F0",
    fontFamily: "'Georgia', 'Times New Roman', serif",
    position: "relative",
    overflow: "hidden",
  },
  bgLayer: {
    position: "fixed",
    inset: 0,
    background: "radial-gradient(ellipse at 20% 20%, rgba(167,139,250,0.08) 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, rgba(78,205,196,0.06) 0%, transparent 60%)",
    pointerEvents: "none",
    zIndex: 0,
  },
  notifContainer: {
    position: "fixed",
    top: 20,
    right: 20,
    zIndex: 9999,
    display: "flex",
    flexDirection: "column",
    gap: 8,
  },
  notif: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 16px",
    borderRadius: 8,
    fontSize: 13,
    fontFamily: "'Courier New', monospace",
    backdropFilter: "blur(10px)",
    animation: "fadeIn 0.3s ease",
    border: "1px solid rgba(255,255,255,0.1)",
  },
  notifSuccess: { background: "rgba(78, 205, 196, 0.15)", color: "#4ECDC4" },
  notifInfo: { background: "rgba(167, 139, 250, 0.15)", color: "#A78BFA" },
  notifDot: { width: 6, height: 6, borderRadius: "50%", background: "currentColor", display: "inline-block" },
  header: {
    position: "relative",
    zIndex: 10,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 24px",
    height: 56,
    borderBottom: "1px solid rgba(255,255,255,0.06)",
    background: "rgba(13,13,20,0.9)",
    backdropFilter: "blur(20px)",
  },
  headerLeft: { display: "flex", alignItems: "center", gap: 16, flex: 1 },
  headerCenter: { display: "flex", alignItems: "center", justifyContent: "center" },
  headerRight: { display: "flex", alignItems: "center", gap: 12, flex: 1, justifyContent: "flex-end" },
  logo: { display: "flex", alignItems: "center", gap: 8 },
  logoIcon: { fontSize: 18, color: "#A78BFA" },
  logoText: { fontSize: 16, fontWeight: 700, letterSpacing: "0.05em", color: "#E8E8F0", fontFamily: "'Georgia', serif" },
  divider: { width: 1, height: 20, background: "rgba(255,255,255,0.15)" },
  titleBtn: {
    background: "none",
    border: "none",
    color: "#B0B0C0",
    fontSize: 14,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: 6,
    padding: "4px 8px",
    borderRadius: 4,
    transition: "background 0.2s",
  },
  editIcon: { fontSize: 12, opacity: 0.5 },
  titleInput: {
    background: "rgba(255,255,255,0.08)",
    border: "1px solid rgba(167,139,250,0.4)",
    color: "#E8E8F0",
    fontSize: 14,
    padding: "4px 10px",
    borderRadius: 4,
    outline: "none",
    fontFamily: "'Georgia', serif",
  },
  statusBadge: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    padding: "4px 10px",
    borderRadius: 20,
    fontSize: 11,
    fontFamily: "'Courier New', monospace",
    letterSpacing: "0.1em",
    fontWeight: 600,
    textTransform: "uppercase",
  },
  statusOnline: { background: "rgba(78,205,196,0.12)", color: "#4ECDC4", border: "1px solid rgba(78,205,196,0.3)" },
  statusOffline: { background: "rgba(255,107,107,0.12)", color: "#FF6B6B", border: "1px solid rgba(255,107,107,0.3)" },
  statusDot: { width: 6, height: 6, borderRadius: "50%", background: "currentColor" },
  avatarStack: { display: "flex", alignItems: "center" },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 12,
    fontWeight: 700,
    color: "#fff",
    border: "2px solid #0D0D14",
    cursor: "pointer",
    fontFamily: "'Courier New', monospace",
  },
  shareBtn: {
    background: "rgba(167,139,250,0.15)",
    border: "1px solid rgba(167,139,250,0.4)",
    color: "#A78BFA",
    padding: "6px 14px",
    borderRadius: 6,
    cursor: "pointer",
    fontSize: 13,
    fontFamily: "'Courier New', monospace",
    letterSpacing: "0.05em",
    transition: "all 0.2s",
  },
  sidebarToggle: {
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
    color: "#888",
    padding: "6px 10px",
    borderRadius: 6,
    cursor: "pointer",
    fontSize: 16,
    transition: "all 0.2s",
  },
  sidebarToggleActive: { background: "rgba(167,139,250,0.15)", color: "#A78BFA", borderColor: "rgba(167,139,250,0.4)" },
  toolbar: {
    position: "relative",
    zIndex: 9,
    display: "flex",
    alignItems: "center",
    gap: 2,
    padding: "0 16px",
    height: 44,
    borderBottom: "1px solid rgba(255,255,255,0.05)",
    background: "rgba(10,10,18,0.8)",
    backdropFilter: "blur(10px)",
  },
  toolBtn: {
    background: "none",
    border: "none",
    color: "#888",
    padding: "6px 10px",
    borderRadius: 4,
    cursor: "pointer",
    fontSize: 13,
    fontFamily: "'Courier New', monospace",
    transition: "all 0.15s",
    minWidth: 32,
    textAlign: "center",
  },
  toolSep: { width: 1, height: 18, background: "rgba(255,255,255,0.1)", margin: "0 4px" },
  meta: { fontSize: 11, color: "#555", fontFamily: "'Courier New', monospace", whiteSpace: "nowrap" },
  main: {
    flex: 1,
    display: "flex",
    position: "relative",
    zIndex: 5,
    overflow: "hidden",
  },
  editorWrap: {
    flex: 1,
    overflow: "auto",
    display: "flex",
    justifyContent: "center",
    padding: "40px 24px",
    background: "transparent",
  },
  page: {
    width: "100%",
    maxWidth: 760,
    minHeight: 800,
    background: "rgba(18,18,28,0.85)",
    backdropFilter: "blur(20px)",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.06)",
    boxShadow: "0 20px 60px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.03)",
    padding: "60px 64px",
    position: "relative",
  },
  editor: {
    width: "100%",
    minHeight: 700,
    background: "none",
    border: "none",
    outline: "none",
    color: "#D8D8E8",
    fontSize: 16,
    lineHeight: 1.85,
    fontFamily: "'Georgia', 'Times New Roman', serif",
    resize: "none",
    letterSpacing: "0.01em",
    caretColor: "#A78BFA",
  },
  sidebar: {
    width: 280,
    borderLeft: "1px solid rgba(255,255,255,0.06)",
    background: "rgba(10,10,18,0.8)",
    backdropFilter: "blur(20px)",
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
  },
  sidebarTabs: {
    display: "flex",
    borderBottom: "1px solid rgba(255,255,255,0.06)",
  },
  tabBtn: {
    flex: 1,
    background: "none",
    border: "none",
    color: "#666",
    padding: "12px 8px",
    cursor: "pointer",
    fontSize: 12,
    fontFamily: "'Courier New', monospace",
    transition: "all 0.2s",
    borderBottom: "2px solid transparent",
  },
  tabBtnActive: { color: "#A78BFA", borderBottomColor: "#A78BFA" },
  sidebarContent: { flex: 1, overflow: "auto", padding: 16 },
  sidebarLabel: {
    fontSize: 10,
    letterSpacing: "0.15em",
    color: "#444",
    fontFamily: "'Courier New', monospace",
    marginBottom: 12,
    textTransform: "uppercase",
  },
  userRow: { display: "flex", alignItems: "center", gap: 10, marginBottom: 14 },
  userDot: { width: 10, height: 10, borderRadius: "50%", flexShrink: 0 },
  userName: { fontSize: 13, color: "#C8C8D8", fontFamily: "'Georgia', serif" },
  userStatus: { fontSize: 11, color: "#555", fontFamily: "'Courier New', monospace" },
  sectionDivider: { height: 1, background: "rgba(255,255,255,0.06)", margin: "16px 0" },
  shareBox: { display: "flex", gap: 6, marginBottom: 8 },
  shareInput: {
    flex: 1,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
    color: "#888",
    fontSize: 11,
    padding: "6px 8px",
    borderRadius: 4,
    fontFamily: "'Courier New', monospace",
    outline: "none",
  },
  copyBtn: {
    background: "rgba(167,139,250,0.15)",
    border: "1px solid rgba(167,139,250,0.3)",
    color: "#A78BFA",
    padding: "6px 10px",
    borderRadius: 4,
    cursor: "pointer",
    fontSize: 11,
    fontFamily: "'Courier New', monospace",
  },
  permRow: { display: "flex", alignItems: "center", justifyContent: "space-between" },
  permLabel: { fontSize: 12, color: "#666", fontFamily: "'Courier New', monospace" },
  permSelect: {
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.1)",
    color: "#A78BFA",
    padding: "4px 8px",
    borderRadius: 4,
    fontSize: 11,
    fontFamily: "'Courier New', monospace",
    outline: "none",
    cursor: "pointer",
  },
  historyRow: { display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 12 },
  historyDot: { width: 6, height: 6, borderRadius: "50%", background: "#A78BFA", flexShrink: 0, marginTop: 5 },
  historyText: { fontSize: 12, color: "#C8C8D8", fontFamily: "'Georgia', serif" },
  historyTime: { fontSize: 10, color: "#555", fontFamily: "'Courier New', monospace" },
  emptyState: { fontSize: 12, color: "#444", fontFamily: "'Courier New', monospace", textAlign: "center", marginTop: 20 },
  footer: {
    position: "relative",
    zIndex: 10,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 24px",
    height: 32,
    borderTop: "1px solid rgba(255,255,255,0.04)",
    background: "rgba(8,8,14,0.9)",
  },
  footerItem: { fontSize: 10, color: "#444", fontFamily: "'Courier New', monospace", letterSpacing: "0.08em" },
  dot: { display: "inline-block", width: 6, height: 6, borderRadius: "50%", marginRight: 6 },
};